import { AnimatePresence, motion } from 'framer-motion'
import { useCallback, useState } from 'react'
import { Experience } from './components/BuildingScene/Experience'
import { FloorPanel } from './components/FloorInteraction/FloorPanel'
import { FloorSelector } from './components/FloorSelector/FloorSelector'
import { HeroOverlay } from './components/Hero/HeroOverlay'
import { LoadingScreen } from './components/LoadingScreen/LoadingScreen'
import { Panels } from './components/Navigation/Panels'
import { TopNav } from './components/Navigation/TopNav'
import { ViewSelector } from './components/Navigation/ViewSelector'
import { useIsMobile } from './hooks/useMediaQuery'
import { actions, useExperience } from './store/experience'
import { AMENITY_SHOTS } from './utils/layout'

export default function App() {
  const isMobile = useIsMobile()
  const introDone = useExperience((s) => s.introDone)
  const selected = useExperience((s) => s.selected)
  const shot = useExperience((s) => s.shot)
  const panel = useExperience((s) => s.panel)
  const [pulse, setPulse] = useState(0)
  const focusSelector = useCallback(() => {
    actions.openPanel(null)
    setPulse((p) => p + 1)
  }, [])

  return (
    <main className="relative h-full w-full overflow-hidden bg-ink">
      <div className="absolute inset-0" aria-label="Interactive 3D model of the AURELIA tower" role="img">
        <Experience isMobile={isMobile} />
      </div>

      {/* UI layer */}
      <motion.div className="pointer-events-none absolute inset-0 z-10 flex flex-col" initial={{ opacity: 0 }} animate={{ opacity: introDone ? 1 : 0 }} transition={{ duration: 1 }}>
        <TopNav onSelectFloor={focusSelector} compact={isMobile} />

        {isMobile ? (
          <>
            <div className="mt-2"><HeroOverlay compact onSelectFloor={focusSelector} /></div>
            <div className="mt-auto flex flex-col gap-2 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
              {!panel && <FloorPanel compact />}
              <div className="pointer-events-auto flex justify-center">{!selected && <ViewSelector />}</div>
              <div className="pointer-events-auto"><FloorSelector compact pulse={pulse} /></div>
            </div>
          </>
        ) : (
          <div className="relative flex flex-1 items-center justify-between px-8 pb-8 xl:px-12">
            <div className="flex h-full flex-col justify-center">
              <HeroOverlay compact={false} onSelectFloor={focusSelector} />
              <FloorPanel compact={false} />
            </div>
            <div className={`pointer-events-auto transition-opacity duration-300 ${panel ? 'pointer-events-none opacity-0' : 'opacity-100'}`} aria-hidden={!!panel}>
              <FloorSelector compact={false} pulse={pulse} />
            </div>
            <div className="absolute bottom-8 left-1/2 flex -translate-x-1/2 flex-col items-center gap-3">
              <AnimatePresence>
                {shot && (
                  <motion.button
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    onClick={() => actions.backToBuilding()}
                    className="glass pointer-events-auto rounded-full px-5 py-2 text-[10px] uppercase tracking-[0.26em] text-champagne"
                  >
                    {AMENITY_SHOTS[shot]?.label} · Back to building
                  </motion.button>
                )}
              </AnimatePresence>
              {!selected && <div className="pointer-events-auto"><ViewSelector /></div>}
            </div>
          </div>
        )}
      </motion.div>

      <Panels compact={isMobile} />
      <LoadingScreen />
    </main>
  )
}
