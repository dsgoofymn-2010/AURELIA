import { actions, useExperience, type ViewSide } from '../../store/experience'

const VIEWS: { id: ViewSide; label: string }[] = [
  { id: 'front', label: 'Front' },
  { id: 'right', label: 'Right' },
  { id: 'rear', label: 'Rear' },
  { id: 'left', label: 'Left' },
]

/** Four-side building exploration. */
export function ViewSelector() {
  const view = useExperience((s) => s.view)
  const selected = useExperience((s) => s.selected)
  const introDone = useExperience((s) => s.introDone)
  return (
    <div className="glass pointer-events-auto flex items-center gap-1 rounded-full p-1" role="toolbar" aria-label="Building view">
      {VIEWS.map((v) => (
        <button
          key={v.id}
          disabled={!introDone}
          onClick={() => actions.setView(v.id)}
          aria-pressed={view === v.id && !selected}
          className={`rounded-full px-3.5 py-1.5 text-[10px] font-medium uppercase tracking-[0.24em] transition disabled:opacity-40 ${
            view === v.id && !selected ? 'bg-champagne text-ink' : 'text-mist hover:text-champagne-soft'
          }`}
        >
          {v.label}
        </button>
      ))}
    </div>
  )
}
