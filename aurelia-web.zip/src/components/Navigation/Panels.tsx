import { AnimatePresence, motion } from 'framer-motion'
import { useState, type FormEvent } from 'react'
import { SITE } from '../../config/site'
import { FLOORS } from '../../data/floors'
import { actions, useExperience } from '../../store/experience'
import { AMENITY_SHOTS } from '../../utils/layout'

const ease = [0.65, 0, 0.35, 1] as const

export function Panels({ compact }: { compact: boolean }) {
  const panel = useExperience((s) => s.panel)
  return (
    <AnimatePresence>
      {panel && (
        <motion.div
          key={panel}
          className={`pointer-events-auto fixed z-40 ${compact ? 'inset-x-3 bottom-3 top-20' : 'right-6 top-24 bottom-6 w-[26rem]'}`}
          initial={{ opacity: 0, x: compact ? 0 : 40, y: compact ? 30 : 0 }}
          animate={{ opacity: 1, x: 0, y: 0, transition: { duration: 0.55, ease } }}
          exit={{ opacity: 0, x: compact ? 0 : 30, y: compact ? 20 : 0, transition: { duration: 0.3 } }}
          role="dialog"
          aria-modal="false"
          aria-label={panel}
        >
          <div className="glass flex h-full flex-col overflow-hidden rounded-md" style={compact ? { background: 'rgba(11,10,16,0.94)' } : undefined}>
            <div className="flex items-center justify-between border-b hairline px-6 py-4">
              <span className="text-[10px] uppercase tracking-luxe text-champagne/80">
                {panel === 'discover' ? 'Discover AURELIA' : panel === 'amenities' ? 'Amenities' : 'Book a visit'}
              </span>
              <button onClick={() => actions.openPanel(null)} className="h-8 w-8 rounded-full border hairline text-champagne-soft hover:bg-champagne/10" aria-label="Close panel">
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-6 py-6">
              {panel === 'discover' && <Discover />}
              {panel === 'amenities' && <Amenities />}
              {panel === 'contact' && <Contact />}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

function Discover() {
  const stats = [
    ['10', 'Full-floor residences'],
    ['45 m', 'Crown height'],
    ['6', 'Terraces per residence'],
    ['3.0 m', 'Clear ceilings'],
  ]
  return (
    <div>
      <h3 className="font-display text-4xl font-light leading-tight text-champagne-soft">A tower drawn in light.</h3>
      <p className="mt-4 text-sm leading-relaxed text-mist">
        AURELIA rises from a marble-clad podium in ten full-floor residences. Curved terraces wrap every level, their edges traced in warm
        architectural light, while a sculpted crown carries the gilded monogram above the skyline.
      </p>
      <div className="mt-6 grid grid-cols-2 gap-4 border-t hairline pt-6">
        {stats.map(([v, l]) => (
          <div key={l}>
            <div className="font-display text-3xl text-gradient-gold">{v}</div>
            <div className="mt-1 text-[10px] uppercase tracking-[0.22em] text-mist">{l}</div>
          </div>
        ))}
      </div>
      <ul className="mt-6 space-y-2 border-t hairline pt-6 text-sm text-mist">
        <li>— Floor-to-ceiling glazing on all four elevations</li>
        <li>— Nero marble, champagne metal and bronze-fin façade</li>
        <li>— Planted terraces on every residence</li>
        <li>— Double-height lobby with private drop-off</li>
      </ul>
      <button
        onClick={() => actions.selectFloor('f05')}
        className="mt-8 w-full rounded-sm bg-champagne py-3 text-[11px] font-semibold uppercase tracking-luxe text-ink transition hover:bg-champagne-soft"
      >
        Open a residence
      </button>
    </div>
  )
}

function Amenities() {
  const desc: Record<string, string> = {
    lobby: 'Double-height arrival hall, marble reception and chandelier rings.',
    fountain: 'Illuminated water feature at the porte-cochère.',
    skygarden: 'Rooftop garden terrace beneath the sculpted canopy.',
    terraces: 'Wrap-around planted terraces on every residence.',
    rear: 'Private rear terraces with bronze screens.',
  }
  return (
    <div className="space-y-3">
      <p className="mb-4 text-sm text-mist">Select an amenity to fly the camera to it on the model.</p>
      {Object.entries(AMENITY_SHOTS).map(([id, a]) => (
        <button
          key={id}
          onClick={() => actions.showShot(id)}
          className="group flex w-full items-center justify-between rounded-sm border hairline px-4 py-4 text-left transition hover:border-champagne/60 hover:bg-champagne/5"
        >
          <span>
            <span className="block font-display text-2xl text-champagne-soft">{a.label}</span>
            <span className="mt-0.5 block text-xs text-mist">{desc[id]}</span>
          </span>
          <span className="text-champagne transition group-hover:translate-x-1">→</span>
        </button>
      ))}
    </div>
  )
}

function Contact() {
  const [sent, setSent] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const d = new FormData(e.currentTarget)
    const name = String(d.get('name') || '').trim()
    const email = String(d.get('email') || '').trim()
    if (!name || !/^\S+@\S+\.\S+$/.test(email)) {
      setErr('Please enter your name and a valid email.')
      return
    }
    setErr(null)
    const body = [
      `Name: ${name}`,
      `Email: ${email}`,
      `Phone: ${d.get('phone') || '-'}`,
      `Preferred date: ${d.get('date') || '-'}`,
      `Residence of interest: ${d.get('floor') || '-'}`,
      '',
      String(d.get('message') || ''),
    ].join('\n')
    window.location.href = `mailto:${SITE.CONTACT_EMAIL}?subject=${encodeURIComponent('AURELIA — Private viewing request')}&body=${encodeURIComponent(body)}`
    setSent(true)
  }
  const field = 'w-full rounded-sm border hairline bg-white/[0.03] px-3 py-2.5 text-sm text-champagne-soft placeholder:text-mist/50 focus:border-champagne/70 focus:outline-none'
  return (
    <form onSubmit={onSubmit} className="space-y-3" noValidate>
      <h3 className="font-display text-3xl font-light text-champagne-soft">Arrange a private viewing</h3>
      <p className="pb-2 text-sm text-mist">
        Our residence advisors will confirm your appointment. Email <span className="select-all text-champagne-soft">{SITE.CONTACT_EMAIL}</span>
      </p>
      <input name="name" placeholder="Full name" className={field} autoComplete="name" />
      <input name="email" type="email" placeholder="Email" className={field} autoComplete="email" />
      <input name="phone" type="tel" placeholder="Phone (optional)" className={field} autoComplete="tel" />
      <div className="grid grid-cols-2 gap-3">
        <input name="date" type="date" className={field} aria-label="Preferred date" />
        <select name="floor" className={field} defaultValue="" aria-label="Residence of interest">
          <option value="" className="bg-ink">Any residence</option>
          {FLOORS.filter((f) => f.kind === 'residential').map((f) => (
            <option key={f.id} value={f.title} className="bg-ink">
              {f.title}
            </option>
          ))}
        </select>
      </div>
      <textarea name="message" rows={3} placeholder="Message (optional)" className={field} />
      {err && <p className="text-xs text-red-300">{err}</p>}
      {sent && (
        <p className="text-xs leading-relaxed text-champagne">
          We tried to open your email app with the request filled in. If nothing opened, write to{' '}
          <span className="select-all font-medium underline underline-offset-2">{SITE.CONTACT_EMAIL}</span>.
        </p>
      )}
      <button type="submit" className="w-full rounded-sm bg-champagne py-3 text-[11px] font-semibold uppercase tracking-luxe text-ink transition hover:bg-champagne-soft">
        Email my request
      </button>
    </form>
  )
}
