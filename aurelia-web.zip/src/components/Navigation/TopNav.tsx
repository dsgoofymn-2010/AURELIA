import { useState } from 'react'
import { actions, useExperience } from '../../store/experience'

export function TopNav({ onSelectFloor, compact }: { onSelectFloor: () => void; compact: boolean }) {
  const panel = useExperience((s) => s.panel)
  const [open, setOpen] = useState(false)
  const links: { label: string; run: () => void; active?: boolean }[] = [
    { label: 'Explore Residences', run: () => actions.selectFloor('f06') },
    { label: 'Select Your Floor', run: onSelectFloor },
    { label: 'Discover AURELIA', run: () => actions.openPanel('discover'), active: panel === 'discover' },
    { label: 'Amenities', run: () => actions.openPanel('amenities'), active: panel === 'amenities' },
  ]
  return (
    <header className="pointer-events-auto flex items-center justify-between px-5 py-4 sm:px-8 sm:py-6">
      <button onClick={() => actions.backToBuilding()} className="font-display text-2xl tracking-[0.42em] text-gradient-gold" aria-label="AURELIA — back to building">
        AURELIA
      </button>
      {!compact ? (
        <nav className="flex items-center gap-7" aria-label="Main">
          {links.map((l) => (
            <button key={l.label} onClick={l.run} className={`text-[10px] font-medium uppercase tracking-[0.26em] transition ${l.active ? 'text-champagne' : 'text-mist hover:text-champagne-soft'}`}>
              {l.label}
            </button>
          ))}
          <button
            onClick={() => actions.openPanel('contact')}
            className="rounded-full border border-champagne/60 px-5 py-2 text-[10px] font-semibold uppercase tracking-[0.26em] text-champagne transition hover:bg-champagne hover:text-ink"
          >
            Book a Visit
          </button>
        </nav>
      ) : (
        <div className="relative">
          <button onClick={() => setOpen((v) => !v)} className="glass h-10 w-10 rounded-full text-champagne" aria-expanded={open} aria-label="Menu">
            {open ? '✕' : '☰'}
          </button>
          {open && (
            <div className="glass absolute right-0 top-12 z-50 flex w-56 flex-col rounded-md p-2">
              {[...links, { label: 'Contact / Book a Visit', run: () => actions.openPanel('contact') }].map((l) => (
                <button
                  key={l.label}
                  onClick={() => {
                    l.run()
                    setOpen(false)
                  }}
                  className="rounded-sm px-3 py-3 text-left text-[11px] uppercase tracking-[0.2em] text-champagne-soft hover:bg-champagne/10"
                >
                  {l.label}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </header>
  )
}
