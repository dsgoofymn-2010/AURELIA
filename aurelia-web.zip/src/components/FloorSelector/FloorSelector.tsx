import { motion } from 'framer-motion'
import { useEffect, useRef } from 'react'
import { FLOORS, type FloorId } from '../../data/floors'
import { actions, useExperience } from '../../store/experience'

/** Floating vertical floor navigation (desktop) / horizontal strip (mobile). */
export function FloorSelector({ compact, pulse }: { compact: boolean; pulse: number }) {
  const hovered = useExperience((s) => s.hovered)
  const selected = useExperience((s) => s.selected)
  const introDone = useExperience((s) => s.introDone)
  const ref = useRef<HTMLDivElement>(null)

  // scroll the active floor into view on mobile
  useEffect(() => {
    if (!compact || !selected) return
    ref.current?.querySelector<HTMLElement>(`[data-floor="${selected}"]`)?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' })
  }, [compact, selected])

  const item = (id: FloorId, short: string) => {
    const isSel = selected === id
    const isHov = hovered === id
    return (
      <button
        key={id}
        data-floor={id}
        disabled={!introDone}
        onMouseEnter={() => actions.hover(id)}
        onMouseLeave={() => actions.hover(null)}
        onFocus={() => actions.hover(id)}
        onBlur={() => actions.hover(null)}
        onClick={() => actions.selectFloor(id)}
        aria-pressed={isSel}
        aria-label={`Select ${short === 'ROOFTOP' || short === 'GROUND' ? short.toLowerCase() : `floor ${short}`}`}
        className={`relative flex shrink-0 items-center justify-center font-sans font-medium tabular-nums transition-colors duration-300 disabled:cursor-wait ${
          compact ? 'h-9 min-w-[3.4rem] rounded-full px-3 text-[11px] tracking-[0.18em]' : 'h-8 w-full justify-end pr-4 text-[11px] tracking-[0.28em]'
        } ${isSel ? 'text-ink' : isHov ? 'text-champagne' : 'text-mist hover:text-champagne-soft'}`}
      >
        {isSel && (
          <motion.span
            layoutId="floor-pill"
            className={`absolute inset-0 bg-champagne ${compact ? 'rounded-full' : 'rounded-sm'}`}
            transition={{ type: 'spring', stiffness: 380, damping: 34 }}
          />
        )}
        {!compact && (
          <span
            className={`absolute left-3 top-1/2 h-px -translate-y-1/2 transition-all duration-300 ${isSel ? 'w-0' : isHov ? 'w-8 bg-champagne' : 'w-3 bg-white/20'}`}
          />
        )}
        <span className="relative">{short}</span>
      </button>
    )
  }

  if (compact) {
    return (
      <motion.div
        key={pulse}
        initial={pulse ? { scale: 1.03 } : false}
        animate={{ scale: 1 }}
        ref={ref}
        className="glass scrollbar-none flex gap-1 overflow-x-auto rounded-full p-1"
        role="toolbar"
        aria-label="Floor selector"
      >
        {[...FLOORS].reverse().map((f) => item(f.id, f.short === 'GROUND' ? 'G' : f.short === 'ROOFTOP' ? 'ROOF' : f.short))}
      </motion.div>
    )
  }

  return (
    <motion.nav
      key={pulse}
      initial={pulse ? { boxShadow: '0 0 0 1px rgba(217,185,138,0.9), 0 0 40px rgba(217,185,138,0.35)' } : false}
      animate={{ boxShadow: '0 0 0 0px rgba(217,185,138,0), 0 0 0px rgba(217,185,138,0)' }}
      transition={{ duration: 1.6 }}
      className="glass w-40 rounded-md py-3"
      aria-label="Floor selector"
    >
      <div className="mb-2 px-4 text-right text-[9px] uppercase tracking-luxe text-champagne/70">Select floor</div>
      <div className="flex flex-col gap-0.5 px-1">{FLOORS.map((f) => item(f.id, f.short))}</div>
    </motion.nav>
  )
}
