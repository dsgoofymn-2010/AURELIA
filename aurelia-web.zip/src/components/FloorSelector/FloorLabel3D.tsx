import { Html } from '@react-three/drei'
import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import * as THREE from 'three'
import { FLOOR_BY_ID } from '../../data/floors'
import { useExperience } from '../../store/experience'
import { floorOffsets } from '../BuildingScene/Building'

/** Floating floor-number tag next to the hovered floor on the model. */
export function FloorLabel3D() {
  const hovered = useExperience((s) => s.hovered)
  const selected = useExperience((s) => s.selected)
  const g = useRef<THREE.Group>(null)
  const def = hovered && hovered !== selected ? FLOOR_BY_ID[hovered] : null
  useFrame(() => {
    if (!g.current || !def) return
    const y = def.kind === 'ground' ? 5.2 : def.kind === 'rooftop' ? def.level + 3 : def.level + 1.6
    g.current.position.set(def.kind === 'ground' ? 18.5 : 10.4, y, 2).add(floorOffsets.get(def.id)!)
  })
  if (!def) return null
  return (
    <group ref={g}>
      <Html center zIndexRange={[5, 0]} style={{ pointerEvents: 'none' }}>
        <div className="flex items-center gap-3 whitespace-nowrap">
          <span className="h-px w-10 bg-champagne" />
          <span className="glass rounded-sm px-3 py-1.5">
            <span className="font-display text-xl text-champagne-soft">{def.short}</span>
            <span className="ml-2 text-[9px] uppercase tracking-[0.24em] text-mist">{def.kind === 'residential' ? 'Residence' : def.title}</span>
          </span>
        </div>
      </Html>
    </group>
  )
}
