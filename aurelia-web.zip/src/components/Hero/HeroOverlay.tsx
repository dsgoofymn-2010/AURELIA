import { AnimatePresence, motion } from 'framer-motion'
import { SITE } from '../../config/site'
import { actions, useExperience } from '../../store/experience'

const ease = [0.22, 1, 0.36, 1] as const

/** Left-hand branding block shown while the full building is in view. */
export function HeroOverlay({ compact, onSelectFloor }: { compact: boolean; onSelectFloor: () => void }) {
  const introDone = useExperience((s) => s.introDone)
  const selected = useExperience((s) => s.selected)
  const shot = useExperience((s) => s.shot)
  const panel = useExperience((s) => s.panel)
  const show = introDone && !selected && !shot && !(compact && panel)
  return (
    <AnimatePresence>
      {show && (
        <motion.section
          key="hero"
          className={compact ? 'pointer-events-auto px-5 text-center' : 'pointer-events-auto max-w-md'}
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0, transition: { duration: 1.1, ease } }}
          exit={{ opacity: 0, y: -10, transition: { duration: 0.4 } }}
          aria-labelledby="hero-title"
        >
          {!compact && <motion.div initial={{ width: 0 }} animate={{ width: 56 }} transition={{ duration: 1.2, ease, delay: 0.2 }} className="h-px bg-champagne" />}
          <h1 id="hero-title" className={`${compact ? 'mt-1' : 'mt-5'} font-display font-light leading-none tracking-[0.18em] text-gradient-gold ${compact ? 'text-4xl' : 'text-6xl xl:text-7xl'}`}>
            {SITE.brand}
          </h1>
          <p className={`mt-4 font-sans font-medium uppercase text-champagne-soft ${compact ? 'text-[10px] tracking-[0.42em]' : 'text-xs tracking-[0.5em]'}`}>{SITE.tagline}</p>
          {!compact && <p className="mt-6 max-w-sm font-display text-xl font-light italic leading-snug text-mist">“{SITE.supporting}”</p>}
          <div className={`flex gap-2 ${compact ? 'mt-5 justify-center' : 'mt-8 gap-3'}`}>
            <button
              onClick={() => actions.selectFloor('f06')}
              className={`rounded-sm bg-champagne font-semibold uppercase text-ink transition hover:bg-champagne-soft ${compact ? 'px-4 py-2.5 text-[9px] tracking-[0.22em]' : 'px-6 py-3 text-[10px] tracking-[0.3em]'}`}
            >
              Explore Residences
            </button>
            <button
              onClick={onSelectFloor}
              className={`rounded-sm border border-champagne/50 bg-ink/40 font-semibold uppercase text-champagne transition hover:border-champagne hover:bg-champagne/10 ${compact ? 'px-4 py-2.5 text-[9px] tracking-[0.22em]' : 'px-6 py-3 text-[10px] tracking-[0.3em]'}`}
            >
              Select Your Floor
            </button>
          </div>
          {!compact && (
            <p className="mt-10 text-[10px] uppercase tracking-[0.3em] text-mist/60">
              Drag to rotate · Hover the tower to preview a floor
            </p>
          )}
        </motion.section>
      )}
    </AnimatePresence>
  )
}
