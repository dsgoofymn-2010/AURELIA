import { useProgress } from '@react-three/drei'
import { AnimatePresence, motion } from 'framer-motion'
import { useExperience } from '../../store/experience'

export function LoadingScreen() {
  const { progress, active } = useProgress()
  const ready = useExperience((s) => s.ready)
  const loadError = useExperience((s) => s.loadError)
  const done = ready && !active && !loadError
  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          key="loader"
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-ink"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 1.1, ease: [0.65, 0, 0.35, 1] } }}
          role="status"
          aria-live="polite"
        >
          <div className="font-display text-5xl font-light tracking-[0.45em] text-gradient-gold sm:text-6xl">AURELIA</div>
          <div className="mt-3 text-[10px] uppercase tracking-luxe text-mist">Live beyond ordinary</div>
          <div className="mt-12 h-px w-56 overflow-hidden bg-white/10">
            <motion.div className="h-full bg-champagne" animate={{ width: `${Math.max(4, progress)}%` }} transition={{ ease: 'easeOut', duration: 0.4 }} />
          </div>
          {loadError ? (
            <div className="mt-4 max-w-sm px-6 text-center text-xs leading-relaxed text-mist">
              <div className="mb-2 uppercase tracking-[0.3em] text-champagne">The 3D model could not load</div>
              <div className="select-all break-words text-mist/80">{loadError}</div>
            </div>
          ) : (
            <div className="mt-3 font-sans text-[11px] tabular-nums tracking-[0.3em] text-mist">
              {progress < 100 ? `LOADING TOWER ${Math.round(progress)}%` : 'PREPARING SCENE'}
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
