import { Component, type ReactNode } from 'react'
import { experience } from '../../store/experience'

/** Catches model-loading / WebGL failures so the loading screen can explain them instead of hanging. */
export class SceneErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  componentDidCatch(error: unknown) {
    const msg = error instanceof Error ? error.message : String(error)
    console.error('[AURELIA] scene failed', error)
    experience.set({ loadError: msg })
  }
  render() {
    return this.state.failed ? null : this.props.children
  }
}
