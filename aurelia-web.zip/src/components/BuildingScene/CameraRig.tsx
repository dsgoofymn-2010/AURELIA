import { OrbitControls } from '@react-three/drei'
import { useFrame, useThree } from '@react-three/fiber'
import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib'
import { dur, EASE_CINEMATIC, gsap } from '../../animations/tweens'
import { actions, experience, useExperience } from '../../store/experience'
import { AMENITY_SHOTS, floorShot, overviewShot, roomShot, type CameraShot } from '../../utils/layout'

const INITIAL_TARGET = new THREE.Vector3(-0.5, 30, 0)

/**
 * Owns the camera: cinematic GSAP moves between shots, OrbitControls for free
 * exploration (mouse + touch) in between.
 */
export function CameraRig({ isMobile }: { isMobile: boolean }) {
  const controls = useRef<OrbitControlsImpl>(null)
  const camera = useThree((s) => s.camera)
  const ready = useExperience((s) => s.ready)
  const focusTick = useExperience((s) => s.focusTick)
  const tl = useRef<gsap.core.Timeline | null>(null)

  const fly = (shot: CameraShot, duration = 2.2, onDone?: () => void) => {
    const c = controls.current
    if (!c) return
    tl.current?.kill()
    c.enabled = false
    // relax limits during the move, apply the shot's limits at the end
    c.minDistance = 0.1
    c.maxDistance = 1000
    c.maxPolarAngle = Math.PI
    const t = tl.current = gsap.timeline({
      defaults: { duration: dur(duration), ease: EASE_CINEMATIC },
      onUpdate: () => c.update(),
      onComplete: () => {
        c.minDistance = shot.minDistance
        c.maxDistance = shot.maxDistance
        c.maxPolarAngle = shot.maxPolar
        c.enabled = true
        c.update()
        onDone?.()
      },
    })
    t.to(camera.position, { x: shot.position.x, y: shot.position.y, z: shot.position.z }, 0)
    t.to(c.target, { x: shot.target.x, y: shot.target.y, z: shot.target.z }, 0)
  }

  // desktop: frame the tower right of centre so the branding / panels have room on the left
  useEffect(() => {
    const cam = camera as THREE.PerspectiveCamera
    cam.filmOffset = isMobile ? 0 : -4.2
    cam.updateProjectionMatrix()
  }, [camera, isMobile])

  // park the camera far away until the model is ready
  useEffect(() => {
    camera.position.set(78, 96, 190)
    controls.current?.target.copy(INITIAL_TARGET)
    controls.current?.update()
  }, [camera])

  // initial entrance
  useEffect(() => {
    if (!ready) return
    camera.position.set(78, 96, 190)
    controls.current?.target.set(-0.5, 30, 0)
    const shot = overviewShot(experience.get().view, isMobile)
    fly(shot, 4.2, () => experience.set({ introDone: true }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready])

  // react to selection / room / view / amenity changes
  useEffect(() => {
    if (!ready || focusTick === 0) return
    const s = experience.get()
    let shot: CameraShot
    if (s.shot && AMENITY_SHOTS[s.shot]) shot = AMENITY_SHOTS[s.shot].shot()
    else if (s.selected && s.room) shot = roomShot(s.selected, s.room)
    else if (s.selected) shot = floorShot(s.selected, isMobile)
    else shot = overviewShot(s.view, isMobile)
    fly(shot, s.room ? 1.8 : 2.2)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusTick, ready])

  // ESC returns to the building
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return
      const s = experience.get()
      if (s.panel) actions.openPanel(null)
      else if (s.room) actions.selectRoom(null)
      else if (s.selected || s.shot) actions.backToBuilding()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  return (
    <>
    <EyeLight />
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.08}
      rotateSpeed={isMobile ? 0.55 : 0.45}
      zoomSpeed={0.7}
      enablePan={false}
      minDistance={22}
      maxDistance={150}
      maxPolarAngle={1.48}
    />
    </>
  )
}

/** Soft fill that travels with the camera while exploring a room interior. */
function EyeLight() {
  const room = useExperience((s) => s.room)
  const light = useRef<THREE.PointLight>(null)
  const camera = useThree((s) => s.camera)
  useFrame(() => {
    if (light.current) light.current.position.copy(camera.position)
  })
  return <pointLight ref={light} intensity={room ? 2.2 : 0} distance={9} decay={2} color="#ffd9b0" />
}
