import { useFrame } from '@react-three/fiber'
import { useMemo, useRef } from 'react'
import * as THREE from 'three'

/**
 * Twilight sky — a real-time port of the Blender "Twilight" world shader:
 * deep blue zenith → purple → magenta → orange-gold horizon band,
 * long sunset-lit cloud banks, cirrus streaks and faint stars.
 */
const vert = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = normalize((modelMatrix * vec4(position, 0.0)).xyz);
    vec4 p = projectionMatrix * viewMatrix * vec4((modelMatrix * vec4(position, 1.0)).xyz, 1.0);
    gl_Position = p.xyww;
  }
`

const frag = /* glsl */ `
  uniform float uTime;
  varying vec3 vDir;

  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
  float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
  }
  float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 7; i++) { v += a * noise(p); p = p * 2.03 + 17.1; a *= 0.52; }
    return v;
  }
  vec3 ramp(float z) {
    // matches the Blender colour ramp (elevation in sin units)
    vec3 c = vec3(0.012, 0.0068, 0.022); // matches scene fog below the horizon
    c = mix(c, vec3(1.0, 0.70, 0.20), smoothstep(-0.02, 0.0, z));
    c = mix(c, vec3(1.0, 0.45, 0.07), smoothstep(0.0, 0.035, z));
    c = mix(c, vec3(0.95, 0.22, 0.06), smoothstep(0.035, 0.08, z));
    c = mix(c, vec3(0.75, 0.10, 0.16), smoothstep(0.08, 0.13, z));
    c = mix(c, vec3(0.45, 0.07, 0.30), smoothstep(0.13, 0.19, z));
    c = mix(c, vec3(0.22, 0.05, 0.33), smoothstep(0.19, 0.27, z));
    c = mix(c, vec3(0.07, 0.04, 0.28), smoothstep(0.27, 0.38, z));
    c = mix(c, vec3(0.02, 0.025, 0.17), smoothstep(0.38, 0.55, z));
    c = mix(c, vec3(0.006, 0.01, 0.08), smoothstep(0.55, 0.8, z));
    return c;
  }
  vec3 cloudRamp(float z) {
    vec3 c = vec3(2.2, 0.8, 0.25);
    c = mix(c, vec3(2.0, 0.5, 0.15), smoothstep(0.0, 0.05, z));
    c = mix(c, vec3(1.5, 0.28, 0.22), smoothstep(0.05, 0.11, z));
    c = mix(c, vec3(0.85, 0.16, 0.38), smoothstep(0.11, 0.18, z));
    c = mix(c, vec3(0.36, 0.09, 0.36), smoothstep(0.18, 0.27, z));
    c = mix(c, vec3(0.12, 0.06, 0.24), smoothstep(0.27, 0.39, z));
    c = mix(c, vec3(0.04, 0.035, 0.13), smoothstep(0.39, 0.6, z));
    return c;
  }
  void main() {
    vec3 d = normalize(vDir);
    float z = d.y;
    // horizontal streaks like a long exposure
    float streak = (noise(vec2(atan(d.x, d.z) * 1.2, z * 45.0)) - 0.5) * 0.035;
    vec3 col = ramp(z + streak);

    // perspective cloud deck
    float den = max(z + 0.06, 0.02);
    vec2 pc = vec2(d.x, d.z) / den;
    float drift = uTime * 0.004;
    float bigRaw = fbm(vec2(pc.x * 0.18 + 3.0 + drift, pc.y * 0.55) * 1.15);
    float big = smoothstep(0.47, 0.58, bigRaw);
    float wisp = smoothstep(0.5, 0.66, fbm(vec2(pc.x * 0.05 + 11.0 + drift * 0.6, pc.y * 1.6) * 2.2));
    float mask = smoothstep(0.004, 0.06, z) * (1.0 - smoothstep(0.55, 0.95, z));
    big *= mask; wisp *= mask * 0.6;
    vec3 cc = cloudRamp(z);
    float rim = smoothstep(0.74, 0.5, bigRaw) * 1.1 + 0.3;
    col = mix(col, cc, wisp);
    col = mix(col, cc * rim, big);

    // stars
    vec2 sp = vec2(atan(d.x, d.z), asin(clamp(z, -1.0, 1.0))) * 160.0;
    vec2 cell = floor(sp); vec2 f = fract(sp) - 0.5;
    float h = hash(cell);
    float star = step(0.985, h) * smoothstep(0.12, 0.0, length(f)) * smoothstep(0.3, 0.6, z) * (1.0 - big);
    col += vec3(0.9, 0.92, 1.0) * star * 1.4;

    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`

export function SkyDome({ animate = true, radius = 900 }: { animate?: boolean; radius?: number }) {
  const mat = useRef<THREE.ShaderMaterial>(null)
  const uniforms = useMemo(() => ({ uTime: { value: 0 } }), [])
  useFrame((_, dt) => {
    if (animate && mat.current) mat.current.uniforms.uTime.value += dt
  })
  return (
    <mesh frustumCulled={false} renderOrder={-10}>
      <sphereGeometry args={[radius, 48, 24]} />
      <shaderMaterial ref={mat} uniforms={uniforms} vertexShader={vert} fragmentShader={frag} side={THREE.BackSide} depthWrite={false} fog={false} />
    </mesh>
  )
}
