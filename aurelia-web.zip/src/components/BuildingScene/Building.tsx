import { useGLTF } from '@react-three/drei'
import { useFrame, type ThreeEvent } from '@react-three/fiber'
import { Select } from '@react-three/postprocessing'
import { useEffect, useLayoutEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { dur, EASE_CINEMATIC, EASE_OUT, gsap } from '../../animations/tweens'
import { SITE } from '../../config/site'
import { FLOORS, type FloorDef, type FloorId } from '../../data/floors'
import { actions, experience, useExperience } from '../../store/experience'
import { FLOOR_LIGHT_MATS, isolateMaterials } from '../../utils/materials'
import { offsetFor } from '../../utils/layout'

/** Live (animated) offset of each floor group — read by the interior loader. */
export const floorOffsets = new Map<FloorId, THREE.Vector3>(FLOORS.map((f) => [f.id, new THREE.Vector3()]))

const STATIC_NODES = ['CORE', 'SITE', 'CAR_BLACK', 'CAR_PEARL']
const noRaycast = () => null

interface FloorRuntime {
  def: FloorDef
  node: THREE.Object3D
  origin: THREE.Vector3
  offset: THREE.Vector3
  lightMats: THREE.MeshStandardMaterial[]
  facadeMats: THREE.MeshStandardMaterial[]
  ceilings: THREE.Object3D[]
  glow: { v: number }
}

export function Building({ isMobile }: { isMobile: boolean }) {
  const gltf = useGLTF(SITE.models.building)
  const scene = gltf.scene

  // ---------- one-time preparation of the loaded model ----------
  const { floors, statics } = useMemo(() => {
    const floors = new Map<FloorId, FloorRuntime>()
    const statics: THREE.Object3D[] = []
    for (const def of FLOORS) {
      const node = scene.getObjectByName(def.node)
      if (!node) {
        console.warn(`[AURELIA] floor node ${def.node} missing from GLB`)
        continue
      }
      const mats = isolateMaterials(node, isMobile)
      const ceilings: THREE.Object3D[] = []
      node.traverse((o) => {
        const m = o as THREE.Mesh
        if (!m.isMesh) return
        m.raycast = noRaycast
        const mat = m.material as THREE.MeshStandardMaterial
        const transparent = mat.transparent
        m.castShadow = !transparent && !isMobile
        m.receiveShadow = !transparent
        if (mat.userData.baseName === 'Ceiling_White') ceilings.push(m)
      })
      floors.set(def.id, {
        def,
        node,
        origin: node.position.clone(),
        offset: floorOffsets.get(def.id)!,
        lightMats: mats.filter((m) => FLOOR_LIGHT_MATS.has(m.userData.baseName)),
        facadeMats: mats.filter((m) => m.userData.baseName === 'Facade_Champagne' || m.userData.baseName === 'Soffit_White'),
        ceilings,
        glow: { v: 1 },
      })
    }
    for (const name of STATIC_NODES) {
      const node = scene.getObjectByName(name)
      if (!node) continue
      isolateMaterials(node, isMobile)
      node.traverse((o) => {
        const m = o as THREE.Mesh
        if (!m.isMesh) return
        m.raycast = noRaycast
        const mat = m.material as THREE.MeshStandardMaterial
        m.castShadow = !mat.transparent && !isMobile && name !== 'SITE'
        m.receiveShadow = !mat.transparent
      })
      statics.push(node)
    }
    return { floors, statics }
  }, [scene, isMobile])

  // dispose GPU resources when the building unmounts
  useEffect(
    () => () => {
      scene.traverse((o) => {
        const m = o as THREE.Mesh
        if (!m.isMesh) return
        const mats = Array.isArray(m.material) ? m.material : [m.material]
        mats.forEach((mat) => mat.dispose())
      })
    },
    [scene],
  )

  // the model is parsed and on the GPU: let the intro begin
  useEffect(() => {
    const t = window.setTimeout(() => experience.set({ ready: true }), 250)
    return () => window.clearTimeout(t)
  }, [])

  // ---------- intro: floors assemble from above ----------
  const ready = useExperience((s) => s.ready)
  useLayoutEffect(() => {
    if (!ready) return
    const list = [...floors.values()].filter((f) => f.def.kind === 'residential' || f.def.kind === 'rooftop')
    list.forEach((f) => f.offset.set(0, 9 + f.def.level * 0.18, 0))
    const tl = gsap.timeline({ delay: dur(0.35) })
    list
      .sort((a, b) => a.def.level - b.def.level)
      .forEach((f, i) => tl.to(f.offset, { y: 0, duration: dur(1.6), ease: EASE_OUT }, dur(0.12) * i))
    return () => {
      tl.kill()
    }
  }, [ready, floors])

  // ---------- selection: explode / restore, light focus, cutaway ----------
  const selected = useExperience((s) => s.selected)
  const room = useExperience((s) => s.room)
  const hovered = useExperience((s) => s.hovered)

  useEffect(() => {
    const tweens: gsap.core.Tween[] = []
    floors.forEach((f, id) => {
      const to = offsetFor(id, selected)
      tweens.push(gsap.to(f.offset, { x: to.x, y: to.y, z: to.z, duration: dur(1.6), ease: EASE_CINEMATIC, overwrite: true }))
    })
    return () => tweens.forEach((t) => t.kill())
  }, [selected, floors])

  // only the focused floor lights up; others dim (the "click a floor and it lights up" brief)
  useEffect(() => {
    floors.forEach((f, id) => {
      let target = 1
      if (selected) {
        const selDef = floors.get(selected)?.def
        if (selDef?.kind === 'residential') target = id === selected ? 1.35 : f.def.kind === 'residential' ? 0.1 : 1
      } else if (hovered) {
        target = id === hovered ? 1.7 : 1
      }
      gsap.to(f.glow, {
        v: target,
        duration: dur(0.7),
        ease: 'sine.out',
        overwrite: true,
        onUpdate: () => f.lightMats.forEach((m) => (m.emissiveIntensity = m.userData.baseEmissive * f.glow.v)),
      })
      // champagne facade picks up a subtle gold tint on hover
      const tint = id === hovered && !selected ? 0.16 : 0
      f.facadeMats.forEach((m) => {
        if (!m.emissive) return
        gsap.to(m, { emissiveIntensity: tint, duration: dur(0.4), overwrite: true })
        m.emissive.set('#d9b98a')
      })
    })
  }, [selected, hovered, floors])

  // cutaway: hide the selected residence's ceiling while viewing it from outside
  useEffect(() => {
    floors.forEach((f, id) => {
      const cut = id === selected && f.def.kind === 'residential' && !room
      f.ceilings.forEach((c) => (c.visible = !cut))
    })
  }, [selected, room, floors])

  // apply animated offsets
  useFrame(() => {
    floors.forEach((f) => f.node.position.copy(f.origin).add(f.offset))
  })

  return (
    <group>
      {statics.map((n) => (
        <primitive key={n.name} object={n} />
      ))}
      {[...floors.values()].map((f) => (
        <Select key={f.def.id} enabled={hovered === f.def.id || selected === f.def.id}>
          <primitive object={f.node} />
        </Select>
      ))}
      <FloorHitVolumes />
    </group>
  )
}

/** Invisible boxes that make each floor hoverable/clickable directly on the model. */
function FloorHitVolumes() {
  const refs = useRef(new Map<FloorId, THREE.Mesh>())
  const introDone = useExperience((s) => s.introDone)
  const room = useExperience((s) => s.room)
  const mat = useMemo(() => new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false, colorWrite: false }), [])
  useFrame(() => {
    refs.current.forEach((mesh, id) => {
      const f = FLOORS.find((x) => x.id === id)!
      mesh.position.set(...f.hit.center).add(floorOffsets.get(id)!)
    })
  })
  const active = introDone && !room
  return (
    <group visible>
      {FLOORS.map((f) => (
        <mesh
          key={f.id}
          ref={(m) => {
            if (m) refs.current.set(f.id, m)
          }}
          material={mat}
          renderOrder={-1}
          onPointerOver={(e: ThreeEvent<PointerEvent>) => {
            if (!active) return
            e.stopPropagation()
            actions.hover(f.id)
            document.body.style.cursor = 'pointer'
          }}
          onPointerOut={() => {
            if (experience.get().hovered === f.id) actions.hover(null)
            document.body.style.cursor = ''
          }}
          onClick={(e: ThreeEvent<MouseEvent>) => {
            if (!active || e.delta > 6) return
            e.stopPropagation()
            actions.selectFloor(f.id)
          }}
        >
          <boxGeometry args={f.hit.size} />
        </mesh>
      ))}
    </group>
  )
}

useGLTF.preload(SITE.models.building)
