import { ContactShadows, Environment, MeshReflectorMaterial, PerformanceMonitor } from '@react-three/drei'
import { Canvas } from '@react-three/fiber'
import { Bloom, EffectComposer, Outline, Selection, Vignette } from '@react-three/postprocessing'
import { Suspense, useState } from 'react'
import * as THREE from 'three'
import { useReducedMotion } from '../../hooks/useReducedMotion'
import { experience } from '../../store/experience'
import { InteriorDetail } from '../InteriorExplorer/InteriorDetail'
import { RoomHotspots } from '../InteriorExplorer/RoomHotspots'
import { FloorLabel3D } from '../FloorSelector/FloorLabel3D'
import { Building } from './Building'
import { CameraRig } from './CameraRig'
import { SceneErrorBoundary } from './SceneErrorBoundary'
import { SkyDome } from './SkyDome'

function Lights({ isMobile }: { isMobile: boolean }) {
  return (
    <>
      <hemisphereLight args={['#7a5aa8', '#120c14', 0.55]} />
      <ambientLight intensity={0.12} color="#b9a6d6" />
      {/* low sunset behind the tower: warm rim + shadows */}
      <directionalLight
        position={[-38, 30, -70]}
        intensity={2.4}
        color="#ff8a4e"
        castShadow={!isMobile}
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0004}
        shadow-normalBias={0.04}
        shadow-camera-left={-45}
        shadow-camera-right={45}
        shadow-camera-top={60}
        shadow-camera-bottom={-10}
        shadow-camera-near={10}
        shadow-camera-far={200}
      />
      {/* cool sky-dome fill from the front */}
      <directionalLight position={[30, 45, 70]} intensity={0.45} color="#8d9cff" />
      {/* lobby glow */}
      <pointLight position={[-2.7, 4.6, 3.5]} intensity={60} distance={22} decay={2} color="#ffb070" />
      <pointLight position={[5.6, 1.2, 11.3]} intensity={10} distance={8} decay={2} color="#cfe4ff" />
    </>
  )
}

function Ground({ isMobile }: { isMobile: boolean }) {
  return (
    <mesh rotation-x={-Math.PI / 2} position={[0, -0.02, 0]} receiveShadow>
      <planeGeometry args={[4000, 4000]} />
      {isMobile ? (
        <meshStandardMaterial color="#09080c" roughness={0.18} metalness={0.4} envMapIntensity={1.2} />
      ) : (
        <MeshReflectorMaterial
          resolution={1024}
          mirror={0.72}
          blur={[260, 80]}
          mixBlur={0.9}
          mixStrength={2.4}
          mixContrast={1.05}
          depthScale={0.6}
          minDepthThreshold={0.6}
          maxDepthThreshold={1.3}
          roughness={0.85}
          metalness={0.5}
          color="#0b0910"
        />
      )}
    </mesh>
  )
}

export function Experience({ isMobile }: { isMobile: boolean }) {
  const reduced = useReducedMotion()
  const [dpr, setDpr] = useState<[number, number] | number>(isMobile ? [1, 1.5] : [1, 1.8])

  return (
    <Canvas
      shadows={!isMobile}
      dpr={dpr}
      gl={{ antialias: true, powerPreference: 'high-performance', stencil: false }}
      camera={{ fov: isMobile ? 42 : 34, near: 0.3, far: 2500, position: [78, 96, 190] }}
      onCreated={({ gl, scene }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping
        gl.toneMappingExposure = 1.05
        if (/[?&]qa\b/.test(window.location.search)) (window as unknown as { __scene: THREE.Scene }).__scene = scene
      }}
      onPointerMissed={() => experience.set({ hovered: null })}
    >
      <PerformanceMonitor
        onDecline={() => {
          setDpr(1)
          experience.set({ quality: 'low' })
        }}
      />
      <fogExp2 attach="fog" args={['#1d1328', 0.0032]} />
      <SkyDome animate={!reduced} />
      <Environment resolution={isMobile ? 128 : 256} frames={1} environmentIntensity={0.65}>
        <SkyDome animate={false} radius={200} />
      </Environment>
      <Lights isMobile={isMobile} />
      <Selection>
        <SceneErrorBoundary>
        <Suspense fallback={null}>
          <Building isMobile={isMobile} />
          <InteriorDetail />
          <RoomHotspots />
          <FloorLabel3D />
          <ContactShadows position={[0, 0.06, 0]} scale={70} far={8} blur={2.6} opacity={0.55} resolution={isMobile ? 256 : 512} frames={1} />
        </Suspense>
        </SceneErrorBoundary>
        <Ground isMobile={isMobile} />
        <EffectComposer multisampling={isMobile ? 0 : 4} autoClear={false}>
          <Outline visibleEdgeColor={0xe6c48f} hiddenEdgeColor={0x6b4f2c} edgeStrength={4} blur width={1200} xRay={false} />
          <Bloom mipmapBlur intensity={isMobile ? 0.4 : 0.55} luminanceThreshold={1.1} luminanceSmoothing={0.25} radius={0.65} />
          <Vignette eskil={false} offset={0.22} darkness={0.62} />
        </EffectComposer>
      </Selection>
      <CameraRig isMobile={isMobile} />
    </Canvas>
  )
}
