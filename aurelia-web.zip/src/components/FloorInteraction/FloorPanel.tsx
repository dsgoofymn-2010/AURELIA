import { AnimatePresence, motion } from 'framer-motion'
import { useState } from 'react'
import { FLOOR_BY_ID, FLOORS, ROOM_BY_ID, ROOMS } from '../../data/floors'
import { actions, useExperience } from '../../store/experience'

const ease = [0.65, 0, 0.35, 1] as const

/** Details + interior navigation for the selected floor. */
export function FloorPanel({ compact }: { compact: boolean }) {
  const selected = useExperience((s) => s.selected)
  const room = useExperience((s) => s.room)
  const [showFacts, setShowFacts] = useState(false)
  const factsVisible = !compact || showFacts
  const def = selected ? FLOOR_BY_ID[selected] : null
  const idx = def ? FLOORS.findIndex((f) => f.id === def.id) : -1
  const up = idx > 0 ? FLOORS[idx - 1] : null
  const down = idx >= 0 && idx < FLOORS.length - 1 ? FLOORS[idx + 1] : null

  return (
    <AnimatePresence mode="wait">
      {def && (
        <motion.aside
          key={def.id}
          initial={{ opacity: 0, x: compact ? 0 : -24, y: compact ? 24 : 0 }}
          animate={{ opacity: 1, x: 0, y: 0, transition: { duration: 0.6, ease, delay: 0.25 } }}
          exit={{ opacity: 0, x: compact ? 0 : -16, y: compact ? 16 : 0, transition: { duration: 0.3 } }}
          className={`glass pointer-events-auto rounded-md ${compact ? 'max-h-[34vh] w-full overflow-y-auto p-4' : 'w-[22rem] p-6'}`}
          aria-label={`${def.title} details`}
        >
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="text-[10px] uppercase tracking-luxe text-champagne/80">
                {def.kind === 'residential' ? `Residence · Palette ${def.variant === 'A' ? 'Ivory' : 'Onyx'}` : def.kind === 'ground' ? 'Arrival' : 'Sky level'}
              </div>
              <h2 className={`mt-1 font-display font-light text-champagne-soft ${compact ? 'text-3xl' : 'text-4xl'}`}>{room && compact ? ROOM_BY_ID[room].name : def.title}</h2>
            </div>
            <div className="flex gap-1 pt-1">
              <button disabled={!up} onClick={() => up && actions.selectFloor(up.id)} className="h-8 w-8 rounded-full border hairline text-champagne-soft transition hover:bg-champagne/10 disabled:opacity-30" aria-label="Floor above">↑</button>
              <button disabled={!down} onClick={() => down && actions.selectFloor(down.id)} className="h-8 w-8 rounded-full border hairline text-champagne-soft transition hover:bg-champagne/10 disabled:opacity-30" aria-label="Floor below">↓</button>
            </div>
          </div>
          {!(compact && room) && <p className={`text-mist ${compact ? 'mt-2 text-xs leading-snug' : 'mt-3 text-sm leading-relaxed'}`}>{room ? ROOM_BY_ID[room].blurb : def.summary}</p>}

          {compact && !room && (
            <button onClick={() => setShowFacts((v) => !v)} className="mt-2 text-[10px] uppercase tracking-[0.22em] text-champagne/80" aria-expanded={showFacts}>
              {showFacts ? 'Hide details −' : 'Residence details +'}
            </button>
          )}
          {factsVisible && !(compact && room) && <dl className="mt-4 grid grid-cols-3 gap-x-3 gap-y-3 border-t hairline pt-4">
            {def.facts.map((f) => (
              <div key={f.label}>
                <dt className="text-[9px] uppercase tracking-[0.22em] text-mist/70">{f.label}</dt>
                <dd className="mt-0.5 font-display text-lg text-champagne-soft">{f.value}</dd>
              </div>
            ))}
          </dl>}

          {def.kind === 'residential' && (
            <div className={`border-t hairline ${compact ? 'mt-3 pt-3' : 'mt-5 pt-4'}`}>
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-luxe text-champagne/80">Explore interior</span>
                {room && (
                  <button onClick={() => actions.selectRoom(null)} className="text-[10px] uppercase tracking-[0.2em] text-mist underline-offset-4 hover:text-champagne hover:underline">
                    Floor overview
                  </button>
                )}
              </div>
              <div className={compact ? 'scrollbar-none -mx-1 flex gap-1.5 overflow-x-auto px-1' : 'flex flex-wrap gap-1.5'}>
                {ROOMS.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => actions.selectRoom(r.id)}
                    aria-pressed={room === r.id}
                    className={`shrink-0 rounded-full border px-3 py-1.5 text-[11px] tracking-wide transition ${
                      room === r.id ? 'border-champagne bg-champagne text-ink' : 'hairline text-champagne-soft hover:border-champagne/60 hover:bg-champagne/10'
                    }`}
                  >
                    {r.name}
                  </button>
                ))}
              </div>
              {room && !compact && <p className="mt-3 text-[11px] text-mist/80">Drag to look around · scroll or pinch to move closer</p>}
            </div>
          )}

          <button
            onClick={() => actions.backToBuilding()}
            className={`flex w-full items-center justify-center gap-3 rounded-sm border border-champagne/50 text-[11px] ${compact ? 'mt-3 py-2.5' : 'mt-5 py-3'} font-medium uppercase tracking-luxe text-champagne transition hover:bg-champagne hover:text-ink`}
          >
            ← Back to building
          </button>
        </motion.aside>
      )}
    </AnimatePresence>
  )
}
