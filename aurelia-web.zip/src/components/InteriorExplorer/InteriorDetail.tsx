import { useGLTF } from '@react-three/drei'
import { useFrame } from '@react-three/fiber'
import { Suspense, useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { SITE } from '../../config/site'
import { FLOOR_BY_ID, ROOMS, type FloorId } from '../../data/floors'
import { useExperience } from '../../store/experience'
import { isolateMaterials } from '../../utils/materials'
import { floorOffsets } from '../BuildingScene/Building'

/**
 * Lazy-loads the detailed interior props (curtains, decor, bathroom fittings,
 * kitchenware, plants…) only for the floor currently opened, and lights its rooms.
 */
export function InteriorDetail() {
  const selected = useExperience((s) => s.selected)
  const def = selected ? FLOOR_BY_ID[selected] : null
  if (!def || def.kind !== 'residential' || !def.variant) return null
  return (
    <Suspense fallback={null}>
      <InteriorProps key={def.id} floor={def.id} url={SITE.models.interior[def.variant]} level={def.level} />
    </Suspense>
  )
}

function InteriorProps({ floor, url, level }: { floor: FloorId; url: string; level: number }) {
  const gltf = useGLTF(url)
  const group = useRef<THREE.Group>(null)
  const scene = useMemo(() => {
    const s = gltf.scene.clone(true)
    isolateMaterials(s, false)
    s.traverse((o) => {
      const m = o as THREE.Mesh
      if (m.isMesh) {
        m.castShadow = false
        m.receiveShadow = true
        m.raycast = () => null
      }
    })
    return s
  }, [gltf.scene])

  useEffect(
    () => () => {
      scene.traverse((o) => {
        const m = o as THREE.Mesh
        if (m.isMesh) (Array.isArray(m.material) ? m.material : [m.material]).forEach((x) => x.dispose())
      })
    },
    [scene],
  )

  useFrame(() => {
    if (group.current) group.current.position.set(0, level, 0).add(floorOffsets.get(floor)!)
  })

  return (
    <group ref={group}>
      <primitive object={scene} />
      {ROOMS.filter((r) => r.id !== 'balcony').map((r) => (
        <pointLight key={r.id} position={[r.hotspot[0], 2.55, r.hotspot[2]]} intensity={4.2} distance={7} decay={2} color="#ffb877" />
      ))}
    </group>
  )
}

useGLTF.preload(SITE.models.interior.A)
