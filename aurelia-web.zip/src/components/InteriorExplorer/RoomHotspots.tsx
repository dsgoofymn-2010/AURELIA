import { Html } from '@react-three/drei'
import { useFrame } from '@react-three/fiber'
import { useEffect, useRef, useState } from 'react'
import * as THREE from 'three'
import { FLOOR_BY_ID, ROOMS } from '../../data/floors'
import { actions, useExperience } from '../../store/experience'
import { floorOffsets } from '../BuildingScene/Building'

/** Clickable room markers floating inside the opened residence. */
export function RoomHotspots() {
  const selected = useExperience((s) => s.selected)
  const room = useExperience((s) => s.room)
  const group = useRef<THREE.Group>(null)
  const [visible, setVisible] = useState(false)
  const def = selected ? FLOOR_BY_ID[selected] : null
  const show = !!def && def.kind === 'residential'

  // wait for the floor to finish sliding out before showing markers
  useEffect(() => {
    setVisible(false)
    if (!show) return
    const t = window.setTimeout(() => setVisible(true), 1500)
    return () => window.clearTimeout(t)
  }, [selected, show])

  useFrame(() => {
    if (group.current && def) group.current.position.set(0, def.level, 0).add(floorOffsets.get(def.id)!)
  })

  if (!show || !visible) return null
  return (
    <group ref={group}>
      {ROOMS.map((r) => (
        <Html key={r.id} position={r.hotspot} center zIndexRange={[6, 0]} style={{ pointerEvents: 'auto' }}>
          <button
            onClick={() => actions.selectRoom(r.id)}
            className={`group flex items-center gap-2 whitespace-nowrap rounded-full border px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.2em] backdrop-blur-md transition ${
              room === r.id
                ? 'border-champagne bg-champagne text-ink'
                : 'border-champagne/40 bg-ink/55 text-champagne-soft hover:border-champagne hover:bg-ink/80'
            }`}
            aria-label={`View ${r.name}`}
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-champagne opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-champagne" />
            </span>
            {r.name}
          </button>
        </Html>
      ))}
    </group>
  )
}
