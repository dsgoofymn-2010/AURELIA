import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './index.css'
import { experience } from './store/experience'

const probe = document.createElement('canvas')
if (!(probe.getContext('webgl2') || probe.getContext('webgl'))) {
  experience.set({ loadError: 'WebGL is turned off or unavailable in this browser. Enable hardware acceleration or try Chrome, Edge or Safari.' })
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
