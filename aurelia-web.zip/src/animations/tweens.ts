import gsap from 'gsap'
import { prefersReducedMotion } from '../hooks/useReducedMotion'

/** Duration helper: collapses motion when the user prefers reduced motion. */
// Keep cinematic moves on schedule even on very slow GPUs (and in headless QA).
const qa = typeof window !== 'undefined' && /[?&]qa\b/.test(window.location.search)
gsap.ticker.lagSmoothing(qa ? 0 : 1000, 16)

export const dur = (seconds: number) => (prefersReducedMotion() ? 0.001 : seconds)

export const EASE_CINEMATIC = 'power3.inOut'
export const EASE_OUT = 'power3.out'
export const EASE_SOFT = 'sine.inOut'

export { gsap }
