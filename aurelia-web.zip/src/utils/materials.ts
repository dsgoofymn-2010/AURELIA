import * as THREE from 'three'

/** Materials that should glow; base intensities are tuned for ACES + bloom. */
export const EMISSIVE_BASE: Record<string, number> = {
  LED_Warm: 2.4,
  LED_Downlight: 4.5,
  Lamp_Shade: 2.6,
  Sign_Gold: 4.5,
  Landscape_Up: 3,
  Water_Jet: 2.2,
  Car_Headlight: 9,
  Car_Taillight: 5,
  Car_Signal: 3,
  Car_Screen: 1.6,
}

/** Interior/facade light materials that dim when another floor is in focus. */
export const FLOOR_LIGHT_MATS = new Set(['LED_Warm', 'LED_Downlight', 'Lamp_Shade'])

const GLASS: Record<string, Partial<THREE.MeshStandardMaterialParameters> & { opacity: number }> = {
  Glass_Window: { color: '#9fb0b4', opacity: 0.16, roughness: 0.04, metalness: 0.1 },
  Glass_Clear: { color: '#d9e6e6', opacity: 0.12, roughness: 0.03, metalness: 0.05 },
  Glass_Frosted: { color: '#e9eef0', opacity: 0.62, roughness: 0.55, metalness: 0 },
  Car_Glass: { color: '#07080a', opacity: 0.82, roughness: 0.03, metalness: 0.3 },
  Water: { color: '#4d6c7c', opacity: 0.6, roughness: 0.02, metalness: 0.1 },
}

/**
 * Normalise materials exported from Blender so they read well in real time.
 * Never mutates shared materials: call on per-group clones.
 */
export function tuneMaterial(m: THREE.Material, isMobile: boolean) {
  const mat = m as THREE.MeshStandardMaterial
  const name = mat.name.replace(/\.\d+$/, '')
  if (GLASS[name]) {
    const g = GLASS[name]
    mat.color = new THREE.Color(g.color as string)
    mat.transparent = true
    mat.opacity = g.opacity
    mat.roughness = g.roughness ?? 0.05
    mat.metalness = g.metalness ?? 0
    mat.depthWrite = false
    mat.envMapIntensity = 1.6
    mat.side = THREE.DoubleSide
    // three's glTF loader may have turned transmission into a physical material: keep it cheap
    if ((mat as THREE.MeshPhysicalMaterial).transmission !== undefined) (mat as THREE.MeshPhysicalMaterial).transmission = 0
  }
  if (name.startsWith('LeafCard')) {
    mat.alphaTest = 0.4
    mat.transparent = false
    mat.depthWrite = true
    mat.side = THREE.DoubleSide
    mat.roughness = 0.7
    mat.color = new THREE.Color('#9cc07a')
    // fake bounce from the balcony downlights / garden uplights so foliage reads at dusk
    mat.emissive = new THREE.Color('#2e3f1c')
    mat.emissiveMap = mat.map
    mat.emissiveIntensity = 0.9
  }
  if (name === 'Bark') mat.color = new THREE.Color('#8a7a6a')
  if (name in EMISSIVE_BASE) {
    mat.emissiveIntensity = EMISSIVE_BASE[name]
    mat.toneMapped = true
  }
  if (name === 'Facade_Champagne') {
    mat.envMapIntensity = 0.85
    mat.roughness = 0.38
    const phys = mat as THREE.MeshPhysicalMaterial
    if (phys.clearcoat) phys.clearcoat = 0 // Blender coat reads as hot spots in real time
  }
  if (name === 'Marble_Nero') { mat.roughness = 0.14; mat.envMapIntensity = 1.4 }
  if (name === 'Paving_Stone' || name === 'Road_Paint' || name === 'Sidewalk_Concrete') mat.envMapIntensity = 1.6
  if (isMobile) {
    const phys = mat as THREE.MeshPhysicalMaterial
    if (phys.clearcoat) phys.clearcoat = 0
    if (phys.sheen) phys.sheen = 0
  }
  mat.userData.baseName = name
  mat.userData.baseEmissive = mat.emissiveIntensity ?? 0
  mat.userData.baseColor = (mat.color ?? new THREE.Color('#fff')).clone()
  mat.needsUpdate = true
  return mat
}

/** Deep-clone the materials of an object tree so each floor can be lit independently. */
export function isolateMaterials(root: THREE.Object3D, isMobile: boolean) {
  const cache = new Map<THREE.Material, THREE.Material>()
  root.traverse((o) => {
    const mesh = o as THREE.Mesh
    if (!mesh.isMesh) return
    const swap = (m: THREE.Material) => {
      if (!cache.has(m)) cache.set(m, tuneMaterial(m.clone(), isMobile))
      return cache.get(m)!
    }
    mesh.material = Array.isArray(mesh.material) ? mesh.material.map(swap) : swap(mesh.material)
  })
  return [...cache.values()] as THREE.MeshStandardMaterial[]
}
