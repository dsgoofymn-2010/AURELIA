import * as THREE from 'three'
import { FLOOR_BY_ID, FLOORS, type FloorId, type RoomId, ROOM_BY_ID } from '../data/floors'
import type { ViewSide } from '../store/experience'

/** How far the selected floor slides out of the facade, and how much the floors above lift. */
export const EXPLODE = { slideOut: 7.5, liftSelected: 0.3, gapAbove: 2.8, groundLift: 4.2 }

/** Target offset (relative to the original glTF transform) of every floor group for a selection. */
export function offsetFor(id: FloorId, selected: FloorId | null): THREE.Vector3 {
  const o = new THREE.Vector3()
  if (!selected) return o
  const sel = FLOOR_BY_ID[selected]
  const me = FLOOR_BY_ID[id]
  if (sel.kind === 'residential') {
    if (id === selected) o.set(0, EXPLODE.liftSelected, EXPLODE.slideOut)
    else if (me.level > sel.level) o.set(0, EXPLODE.gapAbove, 0)
  } else if (sel.kind === 'ground') {
    if (id !== 'ground') o.set(0, EXPLODE.groundLift, 0)
  } else if (sel.kind === 'rooftop') {
    if (id === 'rooftop') o.set(0, 1.4, 3.2)
  }
  return o
}

export interface CameraShot { position: THREE.Vector3; target: THREE.Vector3; minDistance: number; maxDistance: number; maxPolar: number }

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z)
const BUILDING_TARGET = V(-0.5, 22, 0)

const VIEW_AZIMUTH: Record<ViewSide, number> = { front: 0.32, right: Math.PI / 2 + 0.12, rear: Math.PI + 0.32, left: -Math.PI / 2 + 0.12 }

export function overviewShot(view: ViewSide, mobile: boolean): CameraShot {
  const d = mobile ? 128 : 104
  const a = VIEW_AZIMUTH[view]
  return {
    position: V(BUILDING_TARGET.x + Math.sin(a) * d, mobile ? 24 : 17, BUILDING_TARGET.z + Math.cos(a) * d),
    target: mobile ? BUILDING_TARGET.clone().setY(29) : BUILDING_TARGET.clone(),
    minDistance: 24, maxDistance: 170, maxPolar: 1.48,
  }
}

export function floorShot(id: FloorId, mobile: boolean): CameraShot {
  const f = FLOOR_BY_ID[id]
  if (f.kind === 'ground') return { position: V(19, 7.5, 31), target: V(1, 3.4, 3), minDistance: 8, maxDistance: 70, maxPolar: 1.5 }
  if (f.kind === 'rooftop') return { position: V(21, f.level + 15, 31), target: V(-1, f.level + 3.2, 3), minDistance: 10, maxDistance: 80, maxPolar: 1.45 }
  const t = V(-1, f.level + 1.4 + EXPLODE.liftSelected, 0.55 + EXPLODE.slideOut)
  const k = mobile ? 2.0 : 1.5
  return { position: t.clone().add(V(13 * k, 10.5 * k, 19 * k)), target: t, minDistance: 5, maxDistance: 70, maxPolar: 1.52 }
}

export function roomShot(floor: FloorId, room: RoomId): CameraShot {
  const f = FLOOR_BY_ID[floor]
  const r = ROOM_BY_ID[room]
  const off = offsetFor(floor, floor)
  const base = V(0, f.level, 0).add(off)
  const target = V(...r.target).add(base)
  const position = V(...r.camera).add(base)
  return { position, target, minDistance: 0.6, maxDistance: 6, maxPolar: 2.2 }
}

/** Fixed camera shots used by the amenities panel. */
export const AMENITY_SHOTS: Record<string, { label: string; shot: () => CameraShot; floor?: FloorId }> = {
  lobby: { label: 'Arrival Lobby', shot: () => ({ position: V(4, 3.2, 17), target: V(-2.7, 3.6, 2), minDistance: 4, maxDistance: 60, maxPolar: 1.55 }) },
  fountain: { label: 'Fountain Court', shot: () => ({ position: V(13, 2.6, 21), target: V(5.6, 0.8, 11.3), minDistance: 4, maxDistance: 60, maxPolar: 1.55 }) },
  skygarden: { label: 'Sky Garden', shot: () => ({ position: V(-22, 52, 22), target: V(-4.5, 41.5, 3), minDistance: 8, maxDistance: 80, maxPolar: 1.5 }) },
  terraces: { label: 'Garden Terraces', shot: () => ({ position: V(-30, 22, 30), target: V(-7, 20, 4), minDistance: 8, maxDistance: 90, maxPolar: 1.5 }) },
  rear: { label: 'Rear Terraces', shot: () => ({ position: V(-26, 18, -48), target: V(-1, 20, -6), minDistance: 10, maxDistance: 110, maxPolar: 1.5 }) },
}

export const ALL_FLOOR_IDS = FLOORS.map((f) => f.id)
