/** Site-wide settings. Replace CONTACT_EMAIL with the sales inbox before going live. */
export const SITE = {
  brand: 'AURELIA',
  tagline: 'LIVE BEYOND ORDINARY',
  supporting: 'An elevated expression of architecture, luxury and contemporary living.',
  CONTACT_EMAIL: 'sales@aurelia-residences.com',
  models: {
    building: './models/aurelia_building.glb',
    interior: { A: './models/interior_detail_A.glb', B: './models/interior_detail_B.glb' },
  },
}
