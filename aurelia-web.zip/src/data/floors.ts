/**
 * Floor + room registry for AURELIA.
 *
 * All coordinates are in three.js world space (metres, Y-up), converted from the
 * Blender model with (x, y, z)_blender -> (x, z, -y)_three. The building front
 * (Blender -Y) faces +Z here.
 *
 * Node names refer to the groups exported from AURELIA_Web.blend.
 */

export type FloorId =
  | 'ground'
  | 'f01' | 'f02' | 'f03' | 'f04' | 'f05'
  | 'f06' | 'f07' | 'f08' | 'f09' | 'f10'
  | 'rooftop'

export type RoomId = 'living' | 'master' | 'bedroom2' | 'kitchen' | 'dining' | 'bathroom' | 'balcony'

export type Vec3 = [number, number, number]

export interface FloorDef {
  id: FloorId
  /** label shown in the vertical selector */
  short: string
  title: string
  /** exported glTF node name */
  node: string
  kind: 'ground' | 'residential' | 'rooftop'
  /** world Y of the floor slab top */
  level: number
  /** interior variant (residential floors alternate between two finish palettes) */
  variant?: 'A' | 'B'
  /** invisible hit volume used for hover / click on the 3D model */
  hit: { center: Vec3; size: Vec3 }
  summary: string
  facts: { label: string; value: string }[]
}

export interface RoomDef {
  id: RoomId
  name: string
  /** hotspot marker position, floor-local (y measured from the slab) */
  hotspot: Vec3
  /** eye-level camera inside the room, floor-local */
  camera: Vec3
  /** what the camera looks at, floor-local */
  target: Vec3
  blurb: string
}

export const FLOOR_HEIGHT = 3.4
export const FIRST_LEVEL = 6.5
export const levelOf = (n: number) => FIRST_LEVEL + (n - 1) * FLOOR_HEIGHT

const residential = (n: number): FloorDef => {
  const id = `f${String(n).padStart(2, '0')}` as FloorId
  const level = levelOf(n)
  const variant: 'A' | 'B' = n % 2 === 1 ? 'A' : 'B'
  return {
    id,
    short: `${String(n).padStart(2, '0')}F`,
    title: `Level ${String(n).padStart(2, '0')}`,
    node: `FLOOR_${String(n).padStart(2, '0')}`,
    kind: 'residential',
    level,
    variant,
    hit: { center: [-1, level + 1.45, 0.55], size: [19.6, 3.3, 18.7] },
    summary:
      variant === 'A'
        ? 'Full-floor residence in the Ivory palette — oak floors, walnut feature walls and soft ivory textiles.'
        : 'Full-floor residence in the Onyx palette — oak floors, walnut joinery and charcoal upholstery.',
    facts: [
      { label: 'Residence', value: 'Full floor' },
      { label: 'Interior', value: '≈ 224 m²' },
      { label: 'Bedrooms', value: '2' },
      { label: 'Bathroom', value: '1' },
      { label: 'Balconies', value: '6 terraces' },
      { label: 'Ceiling', value: '3.0 m' },
    ],
  }
}

export const FLOORS: FloorDef[] = [
  {
    id: 'rooftop',
    short: 'ROOFTOP',
    title: 'Rooftop',
    node: 'ROOFTOP',
    kind: 'rooftop',
    level: levelOf(11),
    hit: { center: [-1, levelOf(11) + 2.2, 0.6], size: [17.4, 4.8, 16.2] },
    summary: 'Sky garden terrace beneath the sculpted canopy, with the illuminated AURELIA crown and penthouse lounge.',
    facts: [
      { label: 'Garden', value: 'Sky terrace' },
      { label: 'Lounge', value: 'Penthouse' },
      { label: 'Height', value: '≈ 45 m' },
    ],
  },
  ...Array.from({ length: 10 }, (_, i) => residential(10 - i)),
  {
    id: 'ground',
    short: 'GROUND',
    title: 'Ground',
    node: 'GROUND',
    kind: 'ground',
    level: 0,
    hit: { center: [2.1, 3.4, 0.6], size: [31.5, 6.9, 19.6] },
    summary: 'Double-height arrival lobby with marble reception, chandelier rings, water feature and private drop-off.',
    facts: [
      { label: 'Lobby', value: 'Double height' },
      { label: 'Arrival', value: 'Porte-cochère' },
      { label: 'Court', value: 'Fountain' },
    ],
  },
]

export const FLOOR_BY_ID = Object.fromEntries(FLOORS.map((f) => [f.id, f])) as Record<FloorId, FloorDef>
export const RESIDENTIAL = FLOORS.filter((f) => f.kind === 'residential')

/** Rooms exist on every residential floor (both palettes share the same plan). */
export const ROOMS: RoomDef[] = [
  { id: 'living', name: 'Living Room', hotspot: [-1.4, 1.2, 1.0], camera: [-1.0, 1.6, 6.2], target: [-1.4, 1.0, -2.6], blurb: 'Lounge facing the walnut media wall, framed by floor-to-ceiling glass.' },
  { id: 'master', name: 'Master Bedroom', hotspot: [-7.2, 1.1, 3.0], camera: [-7.2, 1.6, -2.2], target: [-7.2, 0.6, 5.6], blurb: 'Corner suite with upholstered headboard, wardrobe wall and wrap-around views.' },
  { id: 'bedroom2', name: 'Second Bedroom', hotspot: [-6.3, 1.1, -4.6], camera: [-3.7, 1.6, -6.4], target: [-6.8, 0.6, -3.6], blurb: 'Quiet rear bedroom with desk nook, opening to the rear terrace.' },
  { id: 'kitchen', name: 'Kitchen', hotspot: [3.6, 1.3, -5.0], camera: [1.9, 1.75, -3.35], target: [4.9, 0.85, -6.3], blurb: 'Walnut kitchen with stone island, integrated appliances and pendant lighting.' },
  { id: 'dining', name: 'Dining', hotspot: [4.3, 1.2, 2.6], camera: [2.4, 1.6, -0.2], target: [5.0, 0.8, 3.6], blurb: 'Six-seat dining beneath a linear pendant, beside the foyer.' },
  { id: 'bathroom', name: 'Bathroom', hotspot: [-1.4, 1.2, -5.0], camera: [-0.3, 1.65, -3.35], target: [-2.0, 0.7, -6.4], blurb: 'Stone-clad bath with freestanding tub, double vanity and walk-in shower.' },
  { id: 'balcony', name: 'Balcony', hotspot: [1.0, 1.0, 8.4], camera: [5.0, 1.6, 9.3], target: [-2.4, 1.0, 7.8], blurb: 'Curved glass terrace with loungers and planted trees.' },
]

export const ROOM_BY_ID = Object.fromEntries(ROOMS.map((r) => [r.id, r])) as Record<RoomId, RoomDef>
