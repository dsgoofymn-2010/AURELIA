import { useSyncExternalStore } from 'react'
import type { FloorId, RoomId } from '../data/floors'

export type ViewSide = 'front' | 'right' | 'rear' | 'left'
export type PanelId = 'discover' | 'amenities' | 'contact' | null

export interface ExperienceState {
  /** GLB finished loading and the intro may start */
  ready: boolean
  /** intro camera move finished; UI may be interactive */
  introDone: boolean
  hovered: FloorId | null
  selected: FloorId | null
  room: RoomId | null
  view: ViewSide
  panel: PanelId
  /** bumps to ask the camera rig to re-frame the current state */
  focusTick: number
  /** amenity camera shot requested from the amenities panel */
  shot: string | null
  quality: 'high' | 'low'
  /** set when the 3D model or WebGL fails, shown on the loading screen */
  loadError: string | null
}

const initial: ExperienceState = {
  ready: false,
  introDone: false,
  hovered: null,
  selected: null,
  room: null,
  view: 'front',
  panel: null,
  focusTick: 0,
  shot: null,
  quality: 'high',
  loadError: null,
}

let state = initial
const listeners = new Set<() => void>()

export const experience = {
  get: () => state,
  set(patch: Partial<ExperienceState>) {
    state = { ...state, ...patch }
    listeners.forEach((l) => l())
  },
  subscribe(l: () => void) {
    listeners.add(l)
    return () => listeners.delete(l)
  },
}

export function useExperience<T>(selector: (s: ExperienceState) => T): T {
  return useSyncExternalStore(experience.subscribe, () => selector(state), () => selector(initial))
}

/* ---------------- actions ---------------- */
export const actions = {
  hover(id: FloorId | null) {
    if (state.hovered !== id) experience.set({ hovered: id })
  },
  selectFloor(id: FloorId) {
    experience.set({ selected: id, room: null, panel: null, shot: null, focusTick: state.focusTick + 1 })
  },
  selectRoom(room: RoomId | null) {
    experience.set({ room, focusTick: state.focusTick + 1 })
  },
  backToBuilding() {
    experience.set({ selected: null, room: null, hovered: null, shot: null, focusTick: state.focusTick + 1 })
  },
  setView(view: ViewSide) {
    experience.set({ view, selected: null, room: null, shot: null, focusTick: state.focusTick + 1 })
  },
  openPanel(panel: PanelId) {
    experience.set({ panel })
  },
  showShot(shot: string) {
    experience.set({ shot, selected: null, room: null, focusTick: state.focusTick + 1 })
  },
}
