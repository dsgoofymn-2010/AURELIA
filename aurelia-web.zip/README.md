# AURELIA — Immersive 3D Architectural Experience

Real-time, interactive website for the AURELIA residential tower, built from the actual Blender model
(`AURELIA_Tower.blend` → web-prepared copy `AURELIA_Web.blend`).

**Stack:** React 19 + TypeScript · Vite · Three.js · React Three Fiber · Drei · @react-three/postprocessing · GSAP · Tailwind CSS v4 · Framer Motion

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in dist/
npm run preview
```

Append `?qa` to the URL to disable GSAP lag-smoothing and expose `window.__scene` (used for headless testing).

---

## 1. Model analysis (what the Blender file actually contains)

| Item | Finding |
|---|---|
| Units / scale | Metric, real-world metres. Tower ≈ 45 m to the crown. |
| Floors | **10 residential floors, already separate** — each a set of ~50 objects tagged `_F01`…`_F10` (slab, 6 balconies with glass rails/handrails/LED edges/downlights, curtain wall, mullions, slat screens, furnished interior, plants, lounge furniture). Nothing needed cutting. |
| Ground | Podium + double-height lobby (29 objects) and lobby fixtures. |
| Rooftop | Crown, "M" monogram panel, roof slab, penthouse block, canopy, roof garden. |
| Full-height elements | Core shaft + bronze fins, marble pilaster, right pilaster, vertical LED lines → kept static (`CORE`). |
| Interiors | Real furnished interiors on every floor, two finish palettes (Ivory on odd floors, Onyx on even floors). |
| Lighting | 119 Blender lights + emissive LED/downlight materials (EEVEE). Not exportable as-is. |
| Materials | Several procedural node setups (marble veins, oak, paving, bark, wet asphalt) and custom EEVEE glass mix shaders — none of which glTF can carry. |
| Foliage | Geometry-nodes leaves/grass ≈ 320 k instances ≈ 38 M triangles — far beyond a browser budget. |

## 2. Blender corrections made (in `AURELIA_Web.blend` only — the original file is untouched)

1. **Missing rooms added.** The plan had no bathroom and no second bedroom. Each residence was re-planned:
   living room, master bedroom, **second bedroom**, **bathroom** (tub, double vanity, WC, walk-in shower, frosted privacy band),
   proper **kitchen** (tall units, cooktop + hood, sink run, island with stools), dining + foyer, balconies.
2. **Rear façade detailed.** The solid 2 m rear wall on every floor was replaced with floor-to-ceiling glazing, mullions,
   a bronze slat screen in front of the bathrooms and **two curved rear balconies per floor** with rails and LED edges.
   The podium rear got slats, a glazed service lobby, a marble panel and LED reveals.
3. **Floor groups.** Every floor's objects were joined into one multi-material mesh named `FLOOR_01` … `FLOOR_10`
   (origin at its slab level), plus `GROUND`, `ROOFTOP`, `CORE`, `SITE`, `CAR_BLACK`, `CAR_PEARL` (≈ 500 draw calls total).
4. **Export-safe materials.** Procedural materials were replaced by generated tileable image textures with box-projected UVs;
   glass/water converted to standard transmission/alpha materials (re-tuned in `src/utils/materials.ts`).
5. **Web foliage.** Geometry-nodes leaves replaced by alpha-tested leaf cards (≈ 520 cards per large tree, ~100 per planter tree);
   hedges and lawns use leafy/grass textures. All curves/text converted to meshes, modifiers applied.
6. **Interior detail split out** into `interior_detail_A.glb` / `interior_detail_B.glb` (curtains, décor, bathroom fittings,
   kitchenware, plants…) which are **lazy-loaded only for the opened floor**.

Result: `aurelia_building.glb` 19 MB raw → **4.1 MB** (meshopt + WebP), interiors 32 KB each.

## 3. How the experience works

| Feature | Where |
|---|---|
| Real-time hero, cinematic entrance, floors assemble from above | `BuildingScene/CameraRig.tsx`, `BuildingScene/Building.tsx` |
| Twilight sky (port of the Blender world shader: gradient, sunset clouds, cirrus, stars) — also used for reflections | `BuildingScene/SkyDome.tsx` |
| Hover a floor (UI or 3D) → gold outline, facade tint, brighter lights, floating floor tag | `Building.tsx`, `FloorSelector/FloorLabel3D.tsx` |
| Click a floor (UI or 3D) → floor slides 7.5 m out of the facade, floors above lift 2.8 m, ceiling cut away, other floors' lights dim, camera flies in | `utils/layout.ts` (`offsetFor`, `floorShot`) |
| Interior: room hotspots + room list, eye-level camera per room, orbit/zoom inside, room lights | `InteriorExplorer/*`, `data/floors.ts` (`ROOMS`) |
| Back to Building / ESC restores all floors (animated from stored original transforms — the model is never modified) | `store/experience.ts`, `Building.tsx` |
| Front / Right / Rear / Left views | `Navigation/ViewSelector.tsx` |
| Discover, Amenities (fly-to camera shots), Book a Visit (validated form → pre-filled email) | `Navigation/Panels.tsx` |
| Loading progress | `LoadingScreen/LoadingScreen.tsx` |

Floor transforms are never written back: each group stores its original glTF position and GSAP animates an
offset vector that is re-applied every frame (`origin + offset`).

**Performance:** meshopt geometry, WebP textures, per-floor material isolation, raycasting only against 12 invisible
hit volumes (not 200 k triangles), lazy interior detail, `PerformanceMonitor` drops DPR on slow devices, mobile disables
shadows/reflector/clearcoat and lowers bloom + environment resolution. `prefers-reduced-motion` collapses all GSAP moves
and disables the cloud drift.

## 4. Configuration

- `src/config/site.ts` → **set `CONTACT_EMAIL` to the real sales inbox** (the booking form opens a pre-filled email to it).
- `src/data/floors.ts` → floor titles, facts, room hotspots and camera positions.

## 5. Known limitations / next steps

- **KTX2 textures:** not produced (the KTX-Software encoder was not available in the build environment). WebP is used;
  to switch, run `gltf-transform uastc`/`etc1s` with `toktx` installed and add a `KTX2Loader` to `useGLTF`.
- Both residence palettes share one floor plan; per-floor plan variations would need extra interior GLBs (the loader already
  supports one GLB per variant — add entries to `SITE.models.interior`).
- Interior furniture is architectural-massing quality (box-modelled). Higher-fidelity furniture can be dropped into the
  interior-detail GLBs without code changes.
- The contact form uses `mailto:`; connect it to a backend/CRM endpoint for production lead capture.
