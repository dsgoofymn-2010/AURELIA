"""
Re-export the web GLBs from AURELIA_Web.blend (run inside Blender: Scripting tab -> Run).

AURELIA_Web.blend already contains the web-ready groups in the WEB_EXPORT collection:
  FLOOR_01 .. FLOOR_10, GROUND, ROOFTOP, CORE, SITE, CAR_BLACK, CAR_PEARL
and the lazy-loaded interior props InteriorProps_A / InteriorProps_B (in _Library).

After exporting, compress with:  node tools/optimize.mjs <in.glb> public/models/<out.glb>
"""
import bpy, os

OUT = bpy.path.abspath('//web_export/')
os.makedirs(OUT, exist_ok=True)
opts = dict(export_format='GLB', use_selection=True, export_apply=True, export_yup=True, export_lights=False,
            export_cameras=False, export_materials='EXPORT', export_image_format='AUTO', export_extras=False)
vl = bpy.context.view_layer

def export(objs, name):
    bpy.ops.object.select_all(action='DESELECT')
    for o in objs: o.select_set(True)
    vl.objects.active = objs[0]
    bpy.ops.export_scene.gltf(filepath=os.path.join(OUT, name), **opts)

export(list(bpy.data.collections['WEB_EXPORT'].objects), 'aurelia_building.glb')
for v in ('A', 'B'):
    o = bpy.data.objects['InteriorProps_' + v]
    bpy.context.scene.collection.objects.link(o)
    export([o], f'interior_detail_{v}.glb')
    bpy.context.scene.collection.objects.unlink(o)
print('exported to', OUT)
