import numpy as np
from PIL import Image, ImageDraw, ImageFilter
rng = np.random.default_rng(7)
def fbm(n, octaves=6, base=4, seed=0):
    r = np.random.default_rng(seed); out = np.zeros((n, n)); amp = 1; tot = 0
    for o in range(octaves):
        f = base * 2**o
        g = r.random((f+1, f+1)); g[-1, :] = g[0, :]; g[:, -1] = g[:, 0]   # tileable
        img = Image.fromarray((g*255).astype(np.uint8)).resize((n, n), Image.BICUBIC)
        out += amp * np.asarray(img, dtype=float)/255; tot += amp; amp *= 0.5
    return out / tot
N = 1024
# --- Nero marble: dark base with thin bright veins (tileable)
x = np.linspace(0, 1, N, endpoint=False); X, Y = np.meshgrid(x, x)
w = fbm(N, 7, 3, 1); w2 = fbm(N, 6, 5, 2)
v = np.abs(np.sin((X*2 + Y*1 + w*3.2)*np.pi*2))  # vein field
veins = np.clip(1 - v/0.035, 0, 1)**1.5
v2 = np.abs(np.sin((X*1 - Y*3 + w2*4)*np.pi*2)); veins2 = np.clip(1 - v2/0.02, 0, 1)*0.6
base = 0.035 + 0.03*fbm(N, 5, 8, 3)
m = np.clip(base + 0.75*veins + 0.35*veins2, 0, 1)
rgb = np.stack([m*1.0, m*0.97, m*0.93], -1)
Image.fromarray((rgb*255).astype(np.uint8)).save('marble_nero.jpg', quality=90)
# --- oak floor planks
P = 1024; img = np.zeros((P, P, 3))
plank_h = P//8
for r in range(8):
    off = rng.integers(0, P)
    tone = rng.uniform(0.85, 1.12)
    gx = fbm(P, 5, 2, 10+r)[:plank_h, :] if False else None
    yy = np.arange(plank_h)[:, None]; xx = (np.arange(P)[None, :] + off) % P
    grain = np.sin((yy/plank_h*6 + fbm(P, 5, 3, 20+r)[r*plank_h:(r+1)*plank_h, :]*5)*np.pi*2)*0.5+0.5
    c = np.array([0.42, 0.27, 0.15])*tone
    col = c[None, None, :]*(0.8 + 0.3*grain[..., None])
    col[:2, :, :] *= 0.45  # plank seam
    seam = (xx % (P//2)) < 2; col[:, seam[0], :] *= 0.5
    img[r*plank_h:(r+1)*plank_h] = col
Image.fromarray((np.clip(img, 0, 1)*255).astype(np.uint8)).save('oak_floor.jpg', quality=90)
# --- granite paving tiles (wet dark)
T = 1024; n = fbm(T, 6, 16, 30); speck = (rng.random((T, T)) > 0.985)*0.15
g = 0.09 + 0.05*n + speck
img = np.stack([g, g*0.97, g*0.94], -1)
for k in range(0, T, T//4): img[k:k+3, :, :] = 0.02; img[:, k:k+3, :] = 0.02
Image.fromarray((np.clip(img, 0, 1)*255).astype(np.uint8)).save('paving.jpg', quality=90)
# roughness for paving: tiles glossy, joints rough
r = np.full((T, T), 40, np.uint8)
for k in range(0, T, T//4): r[k:k+3, :] = 200; r[:, k:k+3] = 200
Image.fromarray(r).save('paving_rough.png')
# --- bark
B = 512; n = fbm(B, 6, 4, 40); s = np.sin((np.linspace(0, 1, B)[None, :]*14 + n*3)*np.pi*2)*0.5+0.5
b = 0.05 + 0.12*s*n
Image.fromarray((np.stack([b*1.1, b*0.85, b*0.6], -1).clip(0, 1)*255).astype(np.uint8)).save('bark.jpg', quality=88)
# --- leaf card atlas (RGBA, alpha cutout clusters of leaves)
def leaf_card(path, size=512, n=230, base=(40, 80, 25), seed=3, leaf=(26, 11)):
    r = np.random.default_rng(seed)
    im = Image.new('RGBA', (size, size), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx = cy = size/2
    for i in range(n):
        a = r.uniform(0, 6.283); rad = size*0.44*np.sqrt(r.random())
        px, py = cx + rad*np.cos(a), cy + rad*np.sin(a)
        L, W = leaf[0]*r.uniform(0.7, 1.3), leaf[1]*r.uniform(0.7, 1.2); ang = r.uniform(0, 6.283)
        pts = []
        for t in np.linspace(0, 1, 9):
            pts.append((t, np.sin(t*np.pi)))
        poly = [(px + (t-0.5)*L*np.cos(ang) - s*W/2*np.sin(ang), py + (t-0.5)*L*np.sin(ang) + s*W/2*np.cos(ang)) for t, s in pts] + \
               [(px + (t-0.5)*L*np.cos(ang) + s*W/2*np.sin(ang), py + (t-0.5)*L*np.sin(ang) - s*W/2*np.cos(ang)) for t, s in pts[::-1]]
        k = r.uniform(0.55, 1.35)
        col = tuple(int(min(255, c*k)) for c in base) + (255,)
        d.polygon(poly, fill=col)
    im.save(path)
leaf_card('leaf_card_broad.png', 512, 260, (34, 70, 20), 3, (30, 13))
leaf_card('leaf_card_orn.png', 512, 340, (45, 95, 28), 5, (20, 8))
leaf_card('leaf_card_hedge.png', 512, 900, (22, 52, 14), 9, (14, 7))
# --- hedge tile (opaque leafy texture)
h = Image.new('RGB', (512, 512), (10, 26, 7)); hl = Image.open('leaf_card_hedge.png')
for k in range(4):
    h.paste(hl.rotate(k*90), (0, 0), hl.rotate(k*90))
h.save('hedge.jpg', quality=88)
# --- lawn grass
G = 1024; n = fbm(G, 6, 32, 50); bl = rng.random((G, G))
g = 0.05 + 0.1*n + 0.06*(bl > 0.6)
Image.fromarray((np.stack([g*0.6, g*1.3, g*0.35], -1).clip(0, 1)*255).astype(np.uint8)).save('lawn.jpg', quality=88)
print('ok')
