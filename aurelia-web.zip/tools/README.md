# Asset pipeline tools

- `blender/export_web.py` — run inside `AURELIA_Web.blend` to re-export `aurelia_building.glb` and the two interior-detail GLBs.
- `optimize.mjs` — compresses a GLB for the web: dedup, weld, quantize, **meshopt** geometry compression, **WebP** textures (max 1024 px).
  ```bash
  cd tools && npm i @gltf-transform/core @gltf-transform/extensions @gltf-transform/functions meshoptimizer sharp
  node optimize.mjs ../web_export/aurelia_building.glb ../public/models/aurelia_building.glb
  ```
- `generate_textures.py` — regenerates the tileable textures (marble, oak, paving, bark, leaf cards, hedge, lawn) used by the web copy of the model.
